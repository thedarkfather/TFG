package repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import domain.Result;

public interface ResultRepository  extends JpaRepository<Result,Integer>{

}
